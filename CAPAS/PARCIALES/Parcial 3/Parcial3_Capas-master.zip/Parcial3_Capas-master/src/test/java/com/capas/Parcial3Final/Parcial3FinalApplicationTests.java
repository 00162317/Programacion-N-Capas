package com.capas.Parcial3Final;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Parcial3FinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
