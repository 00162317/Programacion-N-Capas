package com.capas.uca.parcial3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Parcial3FinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(Parcial3FinalApplication.class, args);
		
	}

}
