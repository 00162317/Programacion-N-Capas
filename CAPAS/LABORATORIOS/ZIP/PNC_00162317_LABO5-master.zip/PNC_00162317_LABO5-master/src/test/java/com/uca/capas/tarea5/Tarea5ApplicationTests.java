package com.uca.capas.tarea5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tarea5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
