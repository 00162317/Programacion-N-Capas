package com.capas.TareaTres;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TareaTresApplication {

	public static void main(String[] args) {
		SpringApplication.run(TareaTresApplication.class, args);
	}

}
