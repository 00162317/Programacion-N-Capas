package com.uca.capas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapasApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapasApplication.class, args);
	}

}
