package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TareaLabo2Application {

	public static void main(String[] args) {
		SpringApplication.run(TareaLabo2Application.class, args);
	}

}
