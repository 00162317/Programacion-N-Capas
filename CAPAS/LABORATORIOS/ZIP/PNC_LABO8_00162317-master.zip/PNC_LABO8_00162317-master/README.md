# Laboratorio-8-PNC
Información obtenida de la clase 22 01-2019:

https://drive.google.com/file/d/19iPTFCCiLKipo-c4Nj5yj6oiEye4dgPE/view?usp=sharing
