package com.uca.capas.tarea3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tarea3Application {

	public static void main(String[] args) {
		SpringApplication.run(Tarea3Application.class, args);
	}

}
