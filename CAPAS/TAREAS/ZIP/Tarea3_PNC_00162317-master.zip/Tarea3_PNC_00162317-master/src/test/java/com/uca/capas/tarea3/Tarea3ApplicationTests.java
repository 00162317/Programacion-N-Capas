package com.uca.capas.tarea3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tarea3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
