package com.uca.capas.simulacro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimulacroApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimulacroApplication.class, args);
	}

}
