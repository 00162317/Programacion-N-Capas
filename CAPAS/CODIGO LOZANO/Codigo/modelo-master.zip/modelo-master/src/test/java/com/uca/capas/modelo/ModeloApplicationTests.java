package com.uca.capas.modelo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModeloApplicationTests {

	@Test
	void contextLoads() {
	}

}
